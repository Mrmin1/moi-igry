import { useCallback, useEffect, useRef, useState } from "react";

type Kind = "star" | "gold" | "meteor" | "heart";
interface Item {
  x: number;
  y: number;
  vy: number;
  r: number;
  kind: Kind;
  rot: number;
  vr: number;
}
interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  color: string;
  size: number;
}
interface Popup {
  x: number;
  y: number;
  text: string;
  life: number;
  color: string;
}

const W = 480;
const H = 720;
const PLAYER_W = 90;
const PLAYER_H = 22;

function starPath(ctx: CanvasRenderingContext2D, r: number, spikes = 5) {
  ctx.beginPath();
  for (let i = 0; i < spikes * 2; i++) {
    const rad = i % 2 === 0 ? r : r * 0.45;
    const a = (Math.PI / spikes) * i - Math.PI / 2;
    const px = Math.cos(a) * rad;
    const py = Math.sin(a) * rad;
    if (i === 0) ctx.moveTo(px, py);
    else ctx.lineTo(px, py);
  }
  ctx.closePath();
}

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [phase, setPhase] = useState<"menu" | "play" | "over">("menu");
  const [finalScore, setFinalScore] = useState(0);
  const [best, setBest] = useState(() => Number(localStorage.getItem("star-best") || 0));
  const bestRef = useRef(best);

  const game = useRef({
    items: [] as Item[],
    particles: [] as Particle[],
    popups: [] as Popup[],
    bgStars: Array.from({ length: 80 }, () => ({
      x: Math.random() * W,
      y: Math.random() * H,
      s: Math.random() * 1.8 + 0.3,
      t: Math.random() * 6,
    })),
    px: W / 2,
    targetX: W / 2,
    score: 0,
    lives: 3,
    combo: 0,
    maxCombo: 0,
    spawn: 0,
    time: 0,
    shake: 0,
    keys: { left: false, right: false },
    running: false,
  });

  const start = useCallback(() => {
    const g = game.current;
    g.items = [];
    g.particles = [];
    g.popups = [];
    g.px = W / 2;
    g.targetX = W / 2;
    g.score = 0;
    g.lives = 3;
    g.combo = 0;
    g.maxCombo = 0;
    g.spawn = 0;
    g.time = 0;
    g.shake = 0;
    g.running = true;
    setPhase("play");
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current!;
    const ctx = canvas.getContext("2d")!;
    const g = game.current;
    let raf = 0;
    let last = performance.now();

    const burst = (x: number, y: number, color: string, n = 14) => {
      for (let i = 0; i < n; i++) {
        const a = Math.random() * Math.PI * 2;
        const sp = 40 + Math.random() * 200;
        g.particles.push({
          x,
          y,
          vx: Math.cos(a) * sp,
          vy: Math.sin(a) * sp - 40,
          life: 0.5 + Math.random() * 0.5,
          color,
          size: 2 + Math.random() * 3,
        });
      }
    };

    const endGame = () => {
      g.running = false;
      setFinalScore(g.score);
      if (g.score > bestRef.current) {
        bestRef.current = g.score;
        setBest(g.score);
        localStorage.setItem("star-best", String(g.score));
      }
      setPhase("over");
    };

    const loseLife = (x: number) => {
      g.lives -= 1;
      g.combo = 0;
      g.shake = 0.3;
      burst(x, H - 60, "#f87171", 12);
      if (g.lives <= 0) endGame();
    };

    const update = (dt: number) => {
      // background always moves
      for (const b of g.bgStars) {
        b.t += dt;
        b.y += b.s * 12 * dt;
        if (b.y > H) {
          b.y = 0;
          b.x = Math.random() * W;
        }
      }
      for (const p of g.particles) {
        p.x += p.vx * dt;
        p.y += p.vy * dt;
        p.vy += 300 * dt;
        p.life -= dt;
      }
      g.particles = g.particles.filter((p) => p.life > 0);
      for (const p of g.popups) {
        p.y -= 40 * dt;
        p.life -= dt;
      }
      g.popups = g.popups.filter((p) => p.life > 0);
      if (g.shake > 0) g.shake -= dt;

      if (!g.running) return;
      g.time += dt;

      // keyboard
      const kv = 520;
      if (g.keys.left) g.targetX -= kv * dt;
      if (g.keys.right) g.targetX += kv * dt;
      g.targetX = Math.max(PLAYER_W / 2, Math.min(W - PLAYER_W / 2, g.targetX));
      g.px += (g.targetX - g.px) * Math.min(1, dt * 18);

      const level = 1 + g.time / 20;
      g.spawn -= dt;
      if (g.spawn <= 0) {
        g.spawn = Math.max(0.28, 0.9 / Math.sqrt(level)) * (0.7 + Math.random() * 0.6);
        const roll = Math.random();
        let kind: Kind = "star";
        const meteorChance = Math.min(0.32, 0.12 + g.time / 400);
        if (roll < meteorChance) kind = "meteor";
        else if (roll < meteorChance + 0.08) kind = "gold";
        else if (roll < meteorChance + 0.1 && g.lives < 3) kind = "heart";
        const r = kind === "gold" ? 16 : kind === "meteor" ? 20 : kind === "heart" ? 14 : 15;
        g.items.push({
          x: r + Math.random() * (W - r * 2),
          y: -r,
          vy: (130 + Math.random() * 60) * (1 + (level - 1) * 0.25) * (kind === "gold" ? 1.5 : 1),
          r,
          kind,
          rot: Math.random() * 6,
          vr: (Math.random() - 0.5) * 4,
        });
      }

      const py = H - 60;
      for (const it of g.items) {
        it.y += it.vy * dt;
        it.rot += it.vr * dt;
        // catch check
        const caught =
          it.y + it.r > py - PLAYER_H / 2 &&
          it.y - it.r < py + PLAYER_H / 2 &&
          Math.abs(it.x - g.px) < PLAYER_W / 2 + it.r * 0.5;
        if (caught) {
          (it as Item & { dead?: boolean }).dead = true;
          if (it.kind === "meteor") {
            burst(it.x, it.y, "#fb923c", 20);
            g.popups.push({ x: it.x, y: it.y - 10, text: "−1 ❤", life: 0.9, color: "#f87171" });
            loseLife(it.x);
          } else if (it.kind === "heart") {
            g.lives = Math.min(3, g.lives + 1);
            burst(it.x, it.y, "#f472b6", 16);
            g.popups.push({ x: it.x, y: it.y - 10, text: "+1 ❤", life: 0.9, color: "#f472b6" });
          } else {
            g.combo += 1;
            g.maxCombo = Math.max(g.maxCombo, g.combo);
            const mult = 1 + Math.floor(g.combo / 5);
            const pts = (it.kind === "gold" ? 5 : 1) * mult;
            g.score += pts;
            burst(it.x, it.y, it.kind === "gold" ? "#fde047" : "#fef08a", it.kind === "gold" ? 24 : 12);
            g.popups.push({
              x: it.x,
              y: it.y - 10,
              text: `+${pts}`,
              life: 0.8,
              color: it.kind === "gold" ? "#fde047" : "#ffffff",
            });
          }
        } else if (it.y - it.r > H) {
          (it as Item & { dead?: boolean }).dead = true;
          if (it.kind === "star" || it.kind === "gold") {
            g.popups.push({ x: it.x, y: H - 30, text: "Мимо!", life: 0.8, color: "#f87171" });
            loseLife(it.x);
          }
        }
      }
      g.items = g.items.filter((i) => !(i as Item & { dead?: boolean }).dead);
    };

    const draw = () => {
      ctx.save();
      if (g.shake > 0) ctx.translate((Math.random() - 0.5) * 10, (Math.random() - 0.5) * 10);
      const grad = ctx.createLinearGradient(0, 0, 0, H);
      grad.addColorStop(0, "#0b1030");
      grad.addColorStop(0.6, "#2a1a5e");
      grad.addColorStop(1, "#5b2a86");
      ctx.fillStyle = grad;
      ctx.fillRect(-20, -20, W + 40, H + 40);

      for (const b of g.bgStars) {
        ctx.globalAlpha = 0.4 + 0.6 * Math.abs(Math.sin(b.t * 1.5));
        ctx.fillStyle = "#fff";
        ctx.beginPath();
        ctx.arc(b.x, b.y, b.s, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.globalAlpha = 1;

      // items
      for (const it of g.items) {
        ctx.save();
        ctx.translate(it.x, it.y);
        if (it.kind === "star" || it.kind === "gold") {
          const gold = it.kind === "gold";
          ctx.shadowColor = gold ? "#facc15" : "#fde68a";
          ctx.shadowBlur = gold ? 28 : 16;
          ctx.rotate(it.rot);
          starPath(ctx, it.r);
          ctx.fillStyle = gold ? "#fbbf24" : "#fde047";
          ctx.fill();
          ctx.lineWidth = 2;
          ctx.strokeStyle = gold ? "#fff7ae" : "#fffbe0";
          ctx.stroke();
        } else if (it.kind === "meteor") {
          ctx.shadowColor = "#fb923c";
          ctx.shadowBlur = 20;
          // tail
          const tg = ctx.createLinearGradient(0, -it.r * 3.5, 0, 0);
          tg.addColorStop(0, "rgba(251,146,60,0)");
          tg.addColorStop(1, "rgba(251,146,60,0.7)");
          ctx.fillStyle = tg;
          ctx.beginPath();
          ctx.moveTo(-it.r * 0.8, 0);
          ctx.lineTo(it.r * 0.8, 0);
          ctx.lineTo(0, -it.r * 3.5);
          ctx.fill();
          ctx.rotate(it.rot);
          ctx.fillStyle = "#6b4a3a";
          ctx.beginPath();
          for (let i = 0; i < 9; i++) {
            const a = (i / 9) * Math.PI * 2;
            const rr = it.r * (0.8 + ((i * 37) % 5) / 14);
            ctx.lineTo(Math.cos(a) * rr, Math.sin(a) * rr);
          }
          ctx.closePath();
          ctx.fill();
          ctx.fillStyle = "#4a3226";
          ctx.beginPath();
          ctx.arc(-5, -3, 4, 0, Math.PI * 2);
          ctx.arc(6, 5, 3, 0, Math.PI * 2);
          ctx.fill();
        } else {
          ctx.shadowColor = "#f472b6";
          ctx.shadowBlur = 16;
          ctx.font = "28px sans-serif";
          ctx.textAlign = "center";
          ctx.textBaseline = "middle";
          ctx.fillText("💖", 0, 0);
        }
        ctx.restore();
      }

      // player
      const py = H - 60;
      ctx.save();
      ctx.translate(g.px, py);
      ctx.shadowColor = "#67e8f9";
      ctx.shadowBlur = 18;
      const pg = ctx.createLinearGradient(-PLAYER_W / 2, 0, PLAYER_W / 2, 0);
      pg.addColorStop(0, "#22d3ee");
      pg.addColorStop(1, "#a78bfa");
      ctx.fillStyle = pg;
      ctx.beginPath();
      ctx.moveTo(-PLAYER_W / 2, -PLAYER_H / 2);
      ctx.lineTo(PLAYER_W / 2, -PLAYER_H / 2);
      ctx.quadraticCurveTo(PLAYER_W / 2 - 8, PLAYER_H / 2 + 8, 0, PLAYER_H / 2 + 8);
      ctx.quadraticCurveTo(-PLAYER_W / 2 + 8, PLAYER_H / 2 + 8, -PLAYER_W / 2, -PLAYER_H / 2);
      ctx.fill();
      ctx.shadowBlur = 0;
      ctx.fillStyle = "rgba(255,255,255,0.5)";
      ctx.fillRect(-PLAYER_W / 2 + 4, -PLAYER_H / 2, PLAYER_W - 8, 3);
      ctx.restore();

      // particles
      for (const p of g.particles) {
        ctx.globalAlpha = Math.max(0, p.life * 1.5);
        ctx.fillStyle = p.color;
        ctx.fillRect(p.x, p.y, p.size, p.size);
      }
      ctx.globalAlpha = 1;

      // popups
      ctx.font = "bold 20px sans-serif";
      ctx.textAlign = "center";
      for (const p of g.popups) {
        ctx.globalAlpha = Math.min(1, p.life * 2);
        ctx.fillStyle = p.color;
        ctx.fillText(p.text, p.x, p.y);
      }
      ctx.globalAlpha = 1;

      // HUD
      if (g.running) {
        ctx.textAlign = "left";
        ctx.fillStyle = "#fff";
        ctx.font = "bold 32px sans-serif";
        ctx.fillText(String(g.score), 18, 44);
        ctx.font = "14px sans-serif";
        ctx.fillStyle = "#c4b5fd";
        ctx.fillText(`Рекорд: ${bestRef.current}`, 18, 64);
        ctx.textAlign = "right";
        ctx.font = "24px sans-serif";
        ctx.fillText("❤".repeat(g.lives) + "🖤".repeat(Math.max(0, 3 - g.lives)), W - 16, 40);
        if (g.combo >= 2) {
          ctx.font = "bold 16px sans-serif";
          ctx.fillStyle = "#fde047";
          const mult = 1 + Math.floor(g.combo / 5);
          ctx.fillText(`Комбо ×${g.combo}${mult > 1 ? `  (очки ×${mult})` : ""}`, W - 16, 66);
        }
      }
      ctx.restore();
    };

    const loop = (now: number) => {
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      update(dt);
      draw();
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);

    const toGameX = (clientX: number) => {
      const rect = canvas.getBoundingClientRect();
      return ((clientX - rect.left) / rect.width) * W;
    };
    const onMove = (e: PointerEvent) => {
      g.targetX = Math.max(PLAYER_W / 2, Math.min(W - PLAYER_W / 2, toGameX(e.clientX)));
    };
    const onKey = (down: boolean) => (e: KeyboardEvent) => {
      if (e.key === "ArrowLeft" || e.key === "a" || e.key === "A" || e.key === "ф") g.keys.left = down;
      if (e.key === "ArrowRight" || e.key === "d" || e.key === "D" || e.key === "в") g.keys.right = down;
      if (e.key.startsWith("Arrow")) e.preventDefault();
    };
    const kd = onKey(true);
    const ku = onKey(false);
    canvas.addEventListener("pointermove", onMove);
    canvas.addEventListener("pointerdown", onMove);
    window.addEventListener("keydown", kd);
    window.addEventListener("keyup", ku);
    return () => {
      cancelAnimationFrame(raf);
      canvas.removeEventListener("pointermove", onMove);
      canvas.removeEventListener("pointerdown", onMove);
      window.removeEventListener("keydown", kd);
      window.removeEventListener("keyup", ku);
    };
  }, []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.key === "Enter" || e.key === " ") && phase !== "play") {
        e.preventDefault();
        start();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [phase, start]);

  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-slate-950 p-2">
      <div
        className="relative w-full select-none"
        style={{ maxWidth: `min(${W}px, calc((100vh - 16px) * ${W / H}))` }}
      >
        <canvas
          ref={canvasRef}
          width={W}
          height={H}
          className="w-full h-auto rounded-2xl shadow-2xl shadow-purple-900/50 touch-none cursor-none block"
        />

        {phase !== "play" && (
          <div className="absolute inset-0 rounded-2xl bg-slate-950/70 backdrop-blur-sm flex flex-col items-center justify-center text-center text-white px-6">
            {phase === "menu" ? (
              <>
                <div className="text-6xl mb-2">⭐</div>
                <h1 className="text-4xl font-extrabold bg-gradient-to-r from-yellow-200 via-amber-400 to-pink-400 bg-clip-text text-transparent">
                  Звёздопад
                </h1>
                <ul className="mt-5 text-sm text-violet-200 space-y-1.5 text-left">
                  <li>⭐ Лови звёзды — +1 очко</li>
                  <li>🌟 Золотая звезда — +5 очков</li>
                  <li>☄️ Метеориты — не лови!</li>
                  <li>💖 Сердечко возвращает жизнь</li>
                  <li>❤️ Пропущенная звезда — минус жизнь</li>
                  <li>🔥 Серия ловли увеличивает множитель</li>
                </ul>
                <p className="mt-4 text-xs text-slate-400">
                  Двигай мышью / пальцем или клавишами ← → / A D
                </p>
              </>
            ) : (
              <>
                <h2 className="text-4xl font-extrabold text-pink-300">Игра окончена</h2>
                <div className="mt-4 text-6xl font-black text-yellow-300">{finalScore}</div>
                <div className="text-violet-200 mt-1">
                  {finalScore > 0 && finalScore >= best ? "🏆 Новый рекорд!" : `Рекорд: ${best}`}
                </div>
                <div className="text-sm text-slate-400 mt-1">
                  Лучшая серия: {game.current.maxCombo}
                </div>
              </>
            )}
            <button
              onClick={start}
              className="mt-7 px-8 py-3 rounded-full font-bold text-lg text-slate-900 bg-gradient-to-r from-yellow-300 to-amber-400 hover:scale-105 active:scale-95 transition shadow-lg shadow-amber-500/30 cursor-pointer"
            >
              {phase === "menu" ? "Играть" : "Ещё раз"}
            </button>
            <p className="mt-3 text-xs text-slate-500">или нажми Пробел / Enter</p>
          </div>
        )}
      </div>
    </div>
  );
}
